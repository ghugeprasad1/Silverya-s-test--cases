<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CheckBox_LostInsuranceQuestion_Yes</name>
   <tag></tag>
   <elementGuidId>45c0d5a2-d5ea-4e84-ba46-7d2b8bd87d4c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@role='radiogroup' and @aria-labelledby='lost-health-insurance-label']//label[.//span[normalize-space(text())='Yes']]//input[@type='radio']&#xd;
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
