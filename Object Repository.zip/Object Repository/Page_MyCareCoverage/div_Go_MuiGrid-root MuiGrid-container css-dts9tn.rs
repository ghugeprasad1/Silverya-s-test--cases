<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Go_MuiGrid-root MuiGrid-container css-dts9tn</name>
   <tag></tag>
   <elementGuidId>510ef4fd-d006-4229-9033-21cd1e007b78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.MuiGrid-root.MuiGrid-container.css-dts9tn</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div[2]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#root div >> internal:has-text=&quot;Include Closed AccountsAdd Patient&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>59af5e3e-89c9-414f-97e8-111be75cc1b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiGrid-root MuiGrid-container css-dts9tn</value>
      <webElementGuid>27376fdb-8ffa-4910-940c-c8c430892b22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>​​​Include Closed AccountsAdd Patient</value>
      <webElementGuid>f74ca7a1-1074-422b-9323-1c4e8b6f57f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-101arav&quot;]/div[@class=&quot;MuiStack-root css-1phb13z&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation3 css-qxhfox&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-container css-dts9tn&quot;]</value>
      <webElementGuid>8d2e475f-314b-4130-98ee-389140292c76</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div[2]/div/div</value>
      <webElementGuid>017701bd-bafd-4145-87d2-f7f39408acb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Go'])[1]/following::div[2]</value>
      <webElementGuid>756ce99c-6150-4629-abf0-0b3c1be98800</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[1]/following::div[2]</value>
      <webElementGuid>930e5603-dc6d-405c-9cc4-6d4d5a592a0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/div</value>
      <webElementGuid>216bf1a9-6b1b-4a1c-a7fb-20ed3c6241ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '​​​Include Closed AccountsAdd Patient' or . = '​​​Include Closed AccountsAdd Patient')]</value>
      <webElementGuid>cf3e31f8-1ca1-4f5b-a8cd-ae87a2bd11e8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
