<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span__MuiTypography-root MuiTypography-body_f664eb</name>
   <tag></tag>
   <elementGuidId>ea4d026f-1cec-4fa7-9cbf-f26be5af737c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>label.MuiFormControlLabel-root.MuiFormControlLabel-labelPlacementEnd.MuiDataGrid-columnsManagementRow.css-1jaw3da > span.MuiTypography-root.MuiTypography-body1.MuiFormControlLabel-label.css-1jpfdw9</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[6]/following::span[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Current Page&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e65843f7-582e-45ae-95f3-ba9c5e9c4469</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiTypography-root MuiTypography-body1 MuiFormControlLabel-label css-1jpfdw9</value>
      <webElementGuid>0af93789-8705-4717-ac8e-4c33072c4c8a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Current Page</value>
      <webElementGuid>4b2283dc-3ad5-40fc-8335-e3d08ff6f3a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;hide-scrollbar&quot;]/body[1]/div[@class=&quot;MuiPopper-root MuiDataGrid-panel css-1107icl&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation8 MuiDataGrid-paper css-9otb32&quot;]/div[@class=&quot;MuiDataGrid-panelWrapper css-1bvqkfl&quot;]/div[@class=&quot;MuiDataGrid-columnsManagement css-x1ccc6&quot;]/label[@class=&quot;MuiFormControlLabel-root MuiFormControlLabel-labelPlacementEnd MuiDataGrid-columnsManagementRow css-1jaw3da&quot;]/span[@class=&quot;MuiTypography-root MuiTypography-body1 MuiFormControlLabel-label css-1jpfdw9&quot;]</value>
      <webElementGuid>043bbe4a-5e85-41c6-a576-0156d3b64c75</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[6]/following::span[3]</value>
      <webElementGuid>16360731-a6dc-4f04-a654-020c5f7ce69a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[5]/following::span[5]</value>
      <webElementGuid>68d9731b-7530-46d4-b802-350e9aa26b41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Show/Hide All'])[1]/preceding::span[3]</value>
      <webElementGuid>0b9acb09-3b91-446a-8fa8-e2343a4770e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset'])[1]/preceding::span[4]</value>
      <webElementGuid>b0498b47-33d1-4204-a60e-e298c6070ffa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Current Page']/parent::*</value>
      <webElementGuid>fd2e011b-0408-439b-9aa2-5aeb7ff23fe8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/label/span[2]</value>
      <webElementGuid>dc84a981-a4f9-4363-b0ad-0de46e8a5beb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Current Page' or . = 'Current Page')]</value>
      <webElementGuid>f994ebda-b894-43c4-a10d-cacbe1c526b8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
