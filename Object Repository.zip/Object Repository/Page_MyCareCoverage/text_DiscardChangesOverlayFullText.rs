<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_DiscardChangesOverlayFullText</name>
   <tag></tag>
   <elementGuidId>7c14b5a8-1e20-4087-9fe0-8d00c64cb303</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//p[contains(normalize-space(), 'You are about to move to the next step while in') &#xd;
    and contains(., 'Edit Mode') &#xd;
    and contains(., 'lost permanently')&#xd;
]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
