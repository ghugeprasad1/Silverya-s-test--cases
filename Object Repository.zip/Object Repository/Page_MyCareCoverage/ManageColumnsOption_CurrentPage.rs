<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ManageColumnsOption_CurrentPage</name>
   <tag></tag>
   <elementGuidId>6febeed4-89a0-42fc-ba4c-33a244c7ed4f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeInherit.css-1cw4hi4</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;:rm:&quot;)/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())='Current Page']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Reviewed column menu&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>988759ab-7f15-4c29-823e-2748f5b503c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4</value>
      <webElementGuid>68bee909-ef94-41c3-8d55-b090433ecbd0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>30a2846e-64c4-466a-b07c-017dd5b06ea9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>dfcc73f3-077f-44e5-be4b-549a4f599481</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>365d8582-4bae-410c-907b-5271f3caf98d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-testid</name>
      <type>Main</type>
      <value>TripleDotsVerticalIcon</value>
      <webElementGuid>d3555817-ee45-4641-998d-43087ea5b421</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;:rm:&quot;)/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4&quot;]</value>
      <webElementGuid>14f0e0e3-12f3-4a4a-9773-3a7348ab762d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reviewed'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>20423916-6bf2-4785-8bfb-cfef4dec7c02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Actions'])[1]/following::*[name()='svg'][3]</value>
      <webElementGuid>a25a3b79-283e-4814-91ce-fc572a371a50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='First Name'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>fa7ff473-c089-48ba-ac57-fa60c9448534</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Name'])[1]/preceding::*[name()='svg'][5]</value>
      <webElementGuid>75930913-1869-4031-aed8-e083be35b44c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
