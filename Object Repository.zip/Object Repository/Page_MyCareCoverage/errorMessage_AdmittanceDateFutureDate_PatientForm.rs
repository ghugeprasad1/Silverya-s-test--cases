<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>errorMessage_AdmittanceDateFutureDate_PatientForm</name>
   <tag></tag>
   <elementGuidId>34d8c427-99ec-4a25-b548-95726e35b6c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//p[contains(@class, 'MuiFormHelperText-root') and normalize-space(text())='Date cannot be in the future.']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
