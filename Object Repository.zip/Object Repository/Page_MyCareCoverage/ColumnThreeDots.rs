<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ColumnThreeDots</name>
   <tag></tag>
   <elementGuidId>ac6075ff-536e-438a-8235-7942285a9e9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//*[@data-testid='TripleDotsVerticalIcon'])[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeInherit.css-1cw4hi4 > path</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;:rm:&quot;)/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4&quot;]/path[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Reviewed column menu&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
      <webElementGuid>f8588ea0-ccd5-4619-bb07-5d42c1ea3874</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z</value>
      <webElementGuid>4f8cbf86-b0a4-441a-91b7-5857b5274694</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;:rm:&quot;)/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4&quot;]/path[1]</value>
      <webElementGuid>528930e4-f224-4597-b490-ebc5c77205b0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
