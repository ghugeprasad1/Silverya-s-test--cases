<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EditModeActivated_Message</name>
   <tag></tag>
   <elementGuidId>b0b62982-d0ec-495d-bd08-908074ede6ef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h6[normalize-space()='Edit Mode Activated']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
