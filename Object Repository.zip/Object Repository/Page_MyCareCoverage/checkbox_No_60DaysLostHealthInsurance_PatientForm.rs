<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkbox_No_60DaysLostHealthInsurance_PatientForm</name>
   <tag></tag>
   <elementGuidId>35bf72c8-9cb8-4863-949a-f95c41cc73db</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@role='radiogroup' and @aria-labelledby='lost-health-insurance-label']//input[@type='radio' and @value='no']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
