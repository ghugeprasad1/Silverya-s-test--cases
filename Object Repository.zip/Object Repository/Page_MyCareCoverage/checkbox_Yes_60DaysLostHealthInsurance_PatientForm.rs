<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkbox_Yes_60DaysLostHealthInsurance_PatientForm</name>
   <tag></tag>
   <elementGuidId>e1ca26ea-1745-4e18-b93c-1275ecc85a3c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[@id='lost-health-insurance-label']/following::input[@type='radio' and @value='yes'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
