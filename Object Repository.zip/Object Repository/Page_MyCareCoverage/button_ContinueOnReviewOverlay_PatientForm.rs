<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_ContinueOnReviewOverlay_PatientForm</name>
   <tag></tag>
   <elementGuidId>eea8df03-5b88-47cb-b52b-056bbeaf344f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//button[normalize-space(text())='Continue' and not(ancestor::div[contains(@style,'display: none')])])[last()]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
