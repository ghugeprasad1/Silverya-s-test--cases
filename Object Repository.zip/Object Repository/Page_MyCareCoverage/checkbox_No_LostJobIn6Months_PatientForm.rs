<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkbox_No_LostJobIn6Months_PatientForm</name>
   <tag></tag>
   <elementGuidId>74b5b8a3-fdc1-4b2a-b68d-46f9c49c321f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@role='radiogroup' and @aria-labelledby='lost-job-label']//input[@type='radio' and @value='no']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
