<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Text_NewQuestiontToLoseInsuranceIn60Days</name>
   <tag></tag>
   <elementGuidId>4c17559c-7baa-404d-b873-8b12edb988c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(), 'In the last 60 days or the upcoming 60 days, have you lost, or will you lose health insurance?')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
