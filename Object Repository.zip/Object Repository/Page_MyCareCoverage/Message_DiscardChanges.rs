<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Message_DiscardChanges</name>
   <tag></tag>
   <elementGuidId>9a2a8b8b-2718-4370-a4dc-c649cddccfb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h6[normalize-space(text())='Discard Changes?']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
