<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_Yes_EnterDate60DaysLostHealthInsurance_PatientForm</name>
   <tag></tag>
   <elementGuidId>6c1a3932-5d7c-471f-899b-e65e25052733</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())='Please enter the date you did, or will, lose insurance (optional)?']/following::input[@placeholder='MM/DD/YYYY']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
