<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkbox_No_VisitRelatedToAccident_PatientForm</name>
   <tag></tag>
   <elementGuidId>016e3822-b7f5-404a-846c-b6bac7e9a3f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@role='radiogroup' and @aria-labelledby='relate_to_accident-label']//input[@type='radio' and @value='no']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
