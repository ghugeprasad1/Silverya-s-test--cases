<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ManageColumnsOption</name>
   <tag></tag>
   <elementGuidId>52ddc6b6-827e-49f8-a5aa-6158c30d8be1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeInherit.css-1cw4hi4</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;:rm:&quot;)/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())='Manage columns']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Reviewed column menu&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>44eb268b-ea1b-470d-b01b-f12831cf637e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4</value>
      <webElementGuid>df1df35d-2ddb-489d-ad09-440740137b5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>10a3bda3-e7be-40e0-81c9-aa7149461730</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>d3e2afc9-8b72-44dd-8500-10f589bbb4c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>1a306e39-bd02-41e9-a190-2acd83355cfe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-testid</name>
      <type>Main</type>
      <value>TripleDotsVerticalIcon</value>
      <webElementGuid>c41e4622-3ce8-4ed3-8962-e3431f42ef10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;:rm:&quot;)/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeInherit css-1cw4hi4&quot;]</value>
      <webElementGuid>033223b4-82c0-440a-aa58-ec8a5c388f31</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reviewed'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>c09dcc14-d282-4413-9b99-34518c23ec3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Actions'])[1]/following::*[name()='svg'][3]</value>
      <webElementGuid>bc3c33cf-f2cb-44dc-8077-7765a3d70b2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='First Name'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>de676af2-add4-442d-89b7-f9c8dd37344f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Name'])[1]/preceding::*[name()='svg'][5]</value>
      <webElementGuid>39962175-f8b4-4485-9137-bebd1c3dbd14</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
