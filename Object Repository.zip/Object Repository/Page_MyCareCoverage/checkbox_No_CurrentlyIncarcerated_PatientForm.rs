<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkbox_No_CurrentlyIncarcerated_PatientForm</name>
   <tag></tag>
   <elementGuidId>f2f36f42-ff68-4a8b-bdab-7910fccfa23e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@role='radiogroup' and @aria-labelledby='incarcerated-label']//input[@type='radio' and @value='no']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
