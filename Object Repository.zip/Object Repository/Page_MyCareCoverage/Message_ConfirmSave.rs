<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Message_ConfirmSave</name>
   <tag></tag>
   <elementGuidId>916c7d7b-cc64-4f11-afd7-f1034659cc57</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h6[normalize-space(text())='Confirm Save']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
