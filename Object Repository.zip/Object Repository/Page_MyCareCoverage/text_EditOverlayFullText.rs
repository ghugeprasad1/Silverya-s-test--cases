<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>text_EditOverlayFullText</name>
   <tag></tag>
   <elementGuidId>966b707f-7aa4-4031-b52b-4597562fb464</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//p[normalize-space()=&quot;You are now in Edit Mode. Any changes you make will be saved to the form. Please review your updates before proceeding.&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
